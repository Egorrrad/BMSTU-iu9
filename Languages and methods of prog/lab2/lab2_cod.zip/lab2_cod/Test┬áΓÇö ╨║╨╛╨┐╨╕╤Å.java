public class Test {
    public static void main(String[] args) {
        Chess Pole=new Chess(10,10);
        Pole.getPole();
        Pole.getPosition(1);
        Pole.changePosition(1,3,1);
    }
}